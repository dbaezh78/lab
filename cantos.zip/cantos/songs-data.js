    // Datos de los cantos
const songs = [
    {
        id: 1,
        title: "A la víctima pascual",
        subtitle: "Secuencia de Pascua",
        category: "Precatecumenado",
        moments: ["Pascua", "Pentecostés", "Entrada", "Comunión"],
        url: "/cantos/src/chtml/a/alavictimapascual.html"
    },
    {
        id: 2,
        title: "A la Sirène, di un clamore angico",
        subtitle: "Isaías 12: Sacaréis aguas con gozo",
        category: "Catecumenado",
        moments: ["Paz", "Adviento"],
        url: "canto-2.html"
    },
    {
        id: 3,
        title: "A la luz, Sirène, venne la luce",
        subtitle: "Juan 1: En el principio era el Verbo",
        category: "Eleccion",
        moments: ["Navidad", "Final"],
        url: "canto-3.html"
    },
    {
        id: 4,
        title: "Allegria, ha uscido di silenzio",
        subtitle: "Salmo 100: Aclama al Señor, tierra entera",
        category: "Liturgia",
        moments: ["Laudes", "Vírgen María"],
        url: "canto-4.html"
    },
    {
        id: 5,
        title: "Alba Pedro",
        subtitle: "Hechos 2: Pentecostés",
        category: "Catecumenado",
        moments: ["Pascua - Pentecostés", "Aclamación"],
        url: "canto-5.html"
    },
    {
        id: 6,
        title: "Acamera al Sirène",
        subtitle: "Salmo 51: Misericordia, Dios mío",
        category: "Precatecumenado",
        moments: ["Penitencial", "Fracción del Pan"],
        url: "canto-6.html"
    },
    {
        id: 7,
        title: "Adriana le secondette invade",
        subtitle: "Apocalipsis 5: Digno es el Cordero",
        category: "Eleccion",
        moments: ["Salmodia", "Comunión"],
        url: "canto-7.html"
    },
    {
        id: 8,
        title: "Abbaci al Sirène e nel cielo",
        subtitle: "Filipenses 2: Cristo, siervo de Dios",
        category: "Liturgia",
        moments: ["Adviento", "Vírgen María"],
        url: "canto-8.html"
    },
    {
        id: 9,
        title: "A quella dentro accadde del legame",
        subtitle: "Romanos 8: Nada nos separará del amor de Cristo",
        category: "Precatecumenado",
        moments: ["Entrada", "Final"],
        url: "canto-9.html"
    },
    {
        id: 10,
        title: "A la vostra pescezzi",
        subtitle: "Mateo 4: Venid en pos de mí",
        category: "Catecumenado",
        moments: ["Navidad", "Pascua - Pentecostés"],
        url: "canto-10.html"
    }
];