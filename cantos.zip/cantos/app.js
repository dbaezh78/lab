document.addEventListener('DOMContentLoaded', function() {
    const songsList = document.querySelector('.songs-list');
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const clearSearch = document.getElementById('clearSearch');
    const categoryFilters = document.querySelectorAll('.category-filter');
    const momentFilters = document.querySelectorAll('.moment-filter');
    
    let activeFilters = {
        category: null,
        moments: []
    };
    
    // Mostrar todos los cantos al cargar la página
    displaySongs(songs);
    
    // Función para mostrar los cantos
    function displaySongs(songsToDisplay) {
        songsList.innerHTML = '';
        
        songsToDisplay.forEach(song => {
            const songCard = document.createElement('a'); // Cambiamos de div a a
            songCard.className = 'song-card';
            songCard.setAttribute('data-category', song.category);
            songCard.setAttribute('data-id', song.id);
            songCard.href = song.url; // Añadimos el atributo href
            
            // Determinar el color de fondo basado en la categoría
            let categoryColorClass = '';
            switch(song.category) {
                case 'Precatecumenado':
                    categoryColorClass = 'white';
                    break;
                case 'Catecumenado':
                    categoryColorClass = 'blue';
                    break;
                case 'Eleccion':
                    categoryColorClass = 'olive';
                    break;
                case 'Liturgia':
                    categoryColorClass = 'yellow';
                    break;
            }
            
            songCard.innerHTML = `
                <h3 class="song-title">${song.title}</h3>
                <p class="song-subtitle">${song.subtitle}</p>
                <div>
                    <span class="song-category" style="background-color: ${getCategoryColor(song.category)}; color: ${getCategoryTextColor(song.category)}">${song.category}</span>
                    ${song.moments.map(moment => `<span class="song-moment">${moment}</span>`).join('')}
                </div>
            `;
            
            songsList.appendChild(songCard);
        });
    }    



    // Función para obtener el color de la categoría
    function getCategoryColor(category) {
        switch(category) {
            case 'Precatecumenado': return '#ffffff';
            case 'Catecumenado': return '#2196F3';
            case 'Eleccion': return '#8BC34A';
            case 'Liturgia': return '#FFEB3B';
            default: return '#9E9E9E';
        }
    }
    
    // Función para obtener el color de texto adecuado para el fondo
    function getCategoryTextColor(category) {
        switch(category) {
            case 'Precatecumenado': return '#333333';
            case 'Liturgia': return '#333333';
            default: return '#ffffff';
        }
    }
    
    // Función para filtrar los cantos
    function filterSongs() {
        let filteredSongs = [...songs];
        
        // Filtrar por categoría
        if (activeFilters.category) {
            filteredSongs = filteredSongs.filter(song => song.category === activeFilters.category);
        }
        
        // Filtrar por momentos litúrgicos
        if (activeFilters.moments.length > 0) {
            filteredSongs = filteredSongs.filter(song => 
                song.moments.some(moment => activeFilters.moments.includes(moment))
            );
        }
        
        // Filtrar por búsqueda
        const searchTerm = searchInput.value.toLowerCase();
        if (searchTerm) {
            filteredSongs = filteredSongs.filter(song => 
                song.title.toLowerCase().includes(searchTerm) || 
                song.subtitle.toLowerCase().includes(searchTerm)
            );
        }
        
        displaySongs(filteredSongs);
    }
    
    // Evento de búsqueda
    searchButton.addEventListener('click', filterSongs);
    searchInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            filterSongs();
        }
    });
    
    // Limpiar búsqueda
    clearSearch.addEventListener('click', function() {
        searchInput.value = '';
        filterSongs();
    });
    
    // Filtros por categoría
    categoryFilters.forEach(filter => {
        filter.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            
            // Si ya está seleccionado, deseleccionar
            if (activeFilters.category === category) {
                activeFilters.category = null;
                this.classList.remove('active');
            } else {
                // Deseleccionar otros filtros de categoría
                categoryFilters.forEach(f => f.classList.remove('active'));
                // Seleccionar este
                activeFilters.category = category;
                this.classList.add('active');
            }
            
            filterSongs();
        });
    });
    
    // Filtros por momento litúrgico
    momentFilters.forEach(filter => {
        filter.addEventListener('click', function() {
            const moment = this.getAttribute('data-moment');
            const index = activeFilters.moments.indexOf(moment);
            
            // Si ya está seleccionado, quitarlo
            if (index > -1) {
                activeFilters.moments.splice(index, 1);
                this.classList.remove('active');
            } else {
                // Añadir a los momentos seleccionados
                activeFilters.moments.push(moment);
                this.classList.add('active');
            }
            
            filterSongs();
        });
    });

    /*
    // Resaltar tarjeta al hacer clic
    songsList.addEventListener('click', function(e) {
        const songCard = e.target.closest('.song-card');
        if (songCard) {
            // Remover resaltado previo
            document.querySelectorAll('.song-card').forEach(card => {
                card.classList.remove('highlight');
            });
            
            // Resaltar esta tarjeta
            songCard.classList.add('highlight');
        }
    });
    */
});
